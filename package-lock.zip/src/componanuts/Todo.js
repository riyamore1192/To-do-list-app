import React, { useState } from "react";
import "./Todo.css";
import {Add,remove} from "./action";
import { useDispatch, useSelector } from "react-redux";

function Todo() {

    const [data, setData] = useState("")

    const dispatch = useDispatch();
    const user_data = useSelector((state) => state.a.user_data)

    function addData() {
        dispatch(Add(data))
        setData("")
    }

    function removedata(id) {
        console.log("Removing item with id:", id); 
       dispatch(remove(id))
    }

    return (
        <div className="container">
            <h1>TO DO LIST APPLICATION</h1>
            <div className="content">
                <input type="text" name="task" value={data} onChange={(e) => setData(e.target.value)} />
                <button onClick={() => addData()}>ADD</button>
           
            <div className="kk">
                <div className="todo-container" >{
                    user_data.map((ele) => {
                        return (
                            <div className="data" key={ele.id}>
                                <li>{ele}</li>
                                <button className="del" onClick={() => removedata(ele.id)}>Delete</button>
                            </div>
                        )
                    })
                }
                
                </div>
               
            </div>

            </div>
        </div>
    )
}

export default Todo;