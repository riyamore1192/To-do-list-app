import { combineReducers } from "redux";
import todoreducers from "./Reducer";

const rootreducers = combineReducers(
{  a:  todoreducers}
);

export default rootreducers;
