
export const Add = (items) => {
    return {
        type: "ADD_DATA",
        payload: items
    }
}

export const remove = (id) => {
    return {
        type: "REMOVE_DATA",
        payload: {id}
    }
}