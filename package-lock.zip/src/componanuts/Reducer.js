const intial_state = {
     user_data : [ ]
}

const todoreducers = (state = intial_state,action) => {
    // console.log('first', action.payload)
    switch(action.type) {
        case "ADD_DATA" :
            return {
                ...state ,
                user_data : [...state.user_data,action.payload]
            };

            case  "REMOVE_DATA" : 

            const dltdata = state.user_data.filter((ele) => ele.id !== action.payload)
            return {
                ...state,
                user_data : dltdata
            };
            default:
      return state;
    }
}

export default todoreducers;