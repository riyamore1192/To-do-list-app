
import './App.css';
import { Provider } from 'react-redux';
import store from './componanuts/store';
import Todo from './componanuts/Todo';

function App() {
  return (
     <div>
       <Provider store={store}>
         <Todo />
       </Provider> 
      <h1>More Riya</h1> 
    </div>
  );
}

export default App;

